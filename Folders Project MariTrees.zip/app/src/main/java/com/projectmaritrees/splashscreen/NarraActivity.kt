package com.projectmaritrees.splashscreen

import android.app.NativeActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class NarraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_narra)

        val narrasources = findViewById<Button>(R.id.narrasources)
        narrasources.setOnClickListener {
            val intent = Intent(this, SourcesActivity::class.java)
            startActivity(intent)
        }

        val profileButton = findViewById<Button>(R.id.profileButton)
        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}