package com.projectmaritrees.splashscreen

import android.app.NativeActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SalingbogbogActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_salingbogbog)

        val salingbogbogsources = findViewById<Button>(R.id.salingbogbogsources)
        salingbogbogsources.setOnClickListener {
            val intent = Intent(this, SourcesActivity::class.java)
            startActivity(intent)
        }

        val profileButton = findViewById<Button>(R.id.profileButton)
        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}