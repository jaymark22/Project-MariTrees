package com.projectmaritrees.splashscreen

import android.app.NativeActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class NativeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_native)

        val banabaButton = findViewById<Button>(R.id.banabaButton)
        banabaButton.setOnClickListener {
            val intent = Intent(this, BanabaActivity::class.java)
            startActivity(intent)
        }

        val baniButton = findViewById<Button>(R.id.baniButton)
        baniButton.setOnClickListener {
            val intent = Intent(this, BaniActivity::class.java)
            startActivity(intent)
        }

        val katmonButton = findViewById<Button>(R.id.katmonButton)
        katmonButton.setOnClickListener {
            val intent = Intent(this, KatmonActivity::class.java)
            startActivity(intent)
        }

        val malabulakButton = findViewById<Button>(R.id.malabulakButton)
        malabulakButton.setOnClickListener {
            val intent = Intent(this, MalabulakActivity::class.java)
            startActivity(intent)
        }

        val molaveButton = findViewById<Button>(R.id.molaveButton)
        molaveButton.setOnClickListener {
            val intent = Intent(this, MolaveActivity::class.java)
            startActivity(intent)
        }

        val narraButton = findViewById<Button>(R.id.narraButton)
        narraButton.setOnClickListener {
            val intent = Intent(this, NarraActivity::class.java)
            startActivity(intent)
        }

        val salingbogbogButton = findViewById<Button>(R.id.salingbogbogButton)
        salingbogbogButton.setOnClickListener {
            val intent = Intent(this, SalingbogbogActivity::class.java)
            startActivity(intent)
        }

        val ylangButton = findViewById<Button>(R.id.ylangButton)
        ylangButton.setOnClickListener {
            val intent = Intent(this, YlangActivity::class.java)
            startActivity(intent)
        }

        val profileButton = findViewById<Button>(R.id.profileButton)
        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}