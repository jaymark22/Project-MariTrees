package com.projectmaritrees.splashscreen

import android.app.NativeActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class YlangActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ylang)

        val ylangsources = findViewById<Button>(R.id.ylangsources)
        ylangsources.setOnClickListener {
            val intent = Intent(this, SourcesActivity::class.java)
            startActivity(intent)
        }

        val profileButton = findViewById<Button>(R.id.profileButton)
        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}